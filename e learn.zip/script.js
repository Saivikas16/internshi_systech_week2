// Sample data for courses (replace with actual data from database)
const courses = [
  {
    title: "Introduction to Programming",
    instructor: "John Doe",
    duration: "4 weeks",
    rating: 4.5,
  },
  {
    title: "Web Development Fundamentals",
    instructor: "Jane Smith",
    duration: "6 weeks",
    rating: 4.8,
  },
  {
    title: "Data Science Basics",
    instructor: "Alice Johnson",
    duration: "5 weeks",
    rating: 4.3,
  },
  {
    title: "Machine Learning Foundations",
    instructor: "Bob Brown",
    duration: "8 weeks",
    rating: 4.7,
  },
  {
    title: "Graphic Design Essentials",
    instructor: "Emily Davis",
    duration: "6 weeks",
    rating: 4.6,
  },
  // Add more courses as needed
];

// Function to display courses
function displayCourses() {
  const mainContent = document.getElementById("main-content");
  mainContent.innerHTML = "";

  courses.forEach((course) => {
    const courseCard = document.createElement("div");
    courseCard.classList.add("course-card");
    courseCard.innerHTML = `
            <h2>${course.title}</h2>
            <p>Instructor: ${course.instructor}</p>
            <p>Duration: ${course.duration}</p>
            <p>Rating: ${course.rating}</p>
            <button>Enroll</button>
        `;
    mainContent.appendChild(courseCard);
  });
}

// Function to handle navigation
function handleNavigation() {
  document.getElementById("coursesLink").addEventListener("click", function () {
    // Redirect to courses page or perform appropriate action
    console.log("Redirecting to Courses page");
    // Example: window.location.href = 'courses.html';
  });

  document
    .getElementById("dashboardLink")
    .addEventListener("click", function () {
      // Redirect to dashboard page or perform appropriate action
      console.log("Redirecting to Dashboard page");
      // Example: window.location.href = 'dashboard.html';
    });

  document
    .getElementById("messagesLink")
    .addEventListener("click", function () {
      // Redirect to messages page or perform appropriate action
      console.log("Redirecting to Messages page");
      // Example: window.location.href = 'messages.html';
    });

  document
    .getElementById("settingsLink")
    .addEventListener("click", function () {
      // Redirect to settings page or perform appropriate action
      console.log("Redirecting to Settings page");
      // Example: window.location.href = 'settings.html';
    });
}

// Call the function to handle navigation
handleNavigation();

// Initial display of courses
displayCourses();
